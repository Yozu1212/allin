#include <stdio.h>
#include <math.h>

int main() {
	
    int a=1, b=1, r=1;
    for (a = 1; a <= 500; a++) {
        for (b = 1; b <= 500; b++) {
            for (r = 1; r <= 500; r++) {
            	
            	
                if (pow(a, 2) + pow(b, 2) == pow(r, 2)) {
                	
                    printf("side1:%d\t side2:%d \n", a, b );
                }
            }
        }
    }
    return 0;
}
