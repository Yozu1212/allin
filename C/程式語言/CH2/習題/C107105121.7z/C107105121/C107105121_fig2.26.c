#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b;
	printf("��J�Ĥ@�ӭ�\n");
	scanf("%d",&a);
	printf("��J�ĤG�ӭ�\n");
	scanf("%d",&b);
	if(a%b==0){
	printf("�O\n");
	}
	if(a%b!=0){
	printf("�_\n");
	}
	system("PAUSE");
	return 0;
}
