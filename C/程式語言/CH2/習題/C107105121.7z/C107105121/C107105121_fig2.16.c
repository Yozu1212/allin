#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int num1,num2;
    printf("��J�@�ӼƦr\n");
    scanf("%d",&num1);
    printf("��J�@�ӼƦr\n");
    scanf("%d",&num2);
    printf("�`�M�O%d\n",num1+num2); 
    printf("�t�O%d\n",num1-num2);
    printf("���n�O%d\n",num1*num2);
    printf("�ӬO%d\n",num1/num2);
    printf("�l�ƬO%d\n",num1%num2);
    system("PAUSE");
	return 0;
}
