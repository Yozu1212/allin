#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	printf("HHHHHHHHH\n");
	printf("    H    \n");
	printf("    H    \n");
	printf("    H    \n");
	printf("HHHHHHHHH\n");
	printf("X       X\n");
	printf("  X   X  \n");
	printf("    X    \n");
	printf("  X   X  \n");
	printf("X       X\n");
	printf("   CCCC   \n");
	printf(" C      C\n");
	printf("C        C\n");
	printf("C        C\n");
	printf(" C      C\n");
	system("PAUSE");
	return 0;
}
