#include<stdio.h> 
#include<ctype.h> 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
{
	printf("%d\n%d\n",786,-786);
	printf("%+d\n%+d\n",786,-786);
	system("pause");
	return 0;
}
