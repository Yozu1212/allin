#include<stdio.h> 
#include<ctype.h> 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
{
	char x;
	chary[9];
	
	printf("%s","enter a string:");
	scanf("%c%8s",&x,y);
	
	puts("the input was:");
	printf("the character \"%c\"and the string \"%s\"\n",x,y);
	system("pause");
	return 0;
}
