#include<stdio.h> 
#include<ctype.h> 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
{
	printf("%4d\n",1); 
	printf("%4d\n",12); 
	printf("%4d\n",123); 
	printf("%4d\n",1234); 
	printf("%4d\n\n",12345); 
	printf("%4d\n",-1); 
	printf("%4d\n",-12); 
	printf("%4d\n",-123); 
	printf("%4d\n",-1234); 
	printf("%4d\n\n",-12345); 
	system("pause");
	return 0;
}
