#include<stdio.h>
#include<stdlib.h>

int main (int arge,char *argv[]) 
{
	int i;
	i=5;
	printf("%d\n",i);
	printf("%d\n",i++);
	printf("%d\n",i);
	
	i=5;
	printf("%d\n",i);
	printf("%d\n",++i);
	printf("%d\n",i);
	system("PAUSE");
	return 0;
}
