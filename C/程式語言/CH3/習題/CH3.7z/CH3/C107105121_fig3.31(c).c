/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 
{
	int x;
	int y;
	x = 5;
	y = 8;
	if(y = 8){
		if(x = 5){
			puts("@@@@@");
			puts("&&&&&");
		}
	else{
	puts("#####");
	puts("$$$$$");
	
	}	
	}
	system("PAUSE");
	return 0;
}
