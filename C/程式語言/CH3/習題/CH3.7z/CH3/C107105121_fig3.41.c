#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float i;
	float j = 3.141592;
	printf("��J��b�|:");
	scanf("%f",&i);
	printf("�ꪽ�|��%.2f\n",i*2);
	printf("��P����%.2f\n",i*2*j);
	printf("�ꭱ�n��%.2f\n",i*i*j);
	system("PAUSE");
	return 0;
}
