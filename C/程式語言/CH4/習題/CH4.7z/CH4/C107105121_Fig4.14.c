#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int i,j,k;
	printf("��J");
	scanf("%d",&i);
	for(j = 1;j <= i;j++){
		k *=  j;
	}
	printf("%d������%d",i,k);
	system("PAUSE");
	return 0;
}
