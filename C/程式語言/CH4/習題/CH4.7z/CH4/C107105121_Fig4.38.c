#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int days;
	printf("�ĴX�Ѻq��");
	scanf("%d", &days);
	while (1){
		switch (days){
			case 1:
			puts("my true love sent to me.");
			puts("A partridge in a pear tree.\n");
			break;
			case 2:
			puts("my true love sent to me.");
			puts("Two turtle doves,and a partridge in a pear tree.");
			break;
			case 3:
			puts("my true love sent to me.");
			puts("Three French hens,two turtle doves,and a partridge in a pear tree.");
			break;
			case 4:
			puts("my true love sent to me.");
			puts("Four calling birds,three French hens, two turtle doves,and a partridge in a pear tree.");
			break;
			case 5:
			puts("my true love sent to me.");
			puts("Five golden rings, four calling birds,three French hens, two turtle doves,and a partridge in a pear tree. ");
			break;
			case 6:
			puts("my true love sent to me.");
			puts("Six geese a-laying, five golden rings, four calling birds,three French hens, two turtle doves,and a partridge in a pear tree.  ");
			break;
			case 7:
			puts("my true love sent to me.");
			puts("Seven swans a-swimming,six geese a-laying, five golden rings, four calling birds,three French hens, two turtle doves,and a partridge in a pear tree. ");
			break;
			case 8:
			puts("my true love sent to me.");
			puts("Eight maids a-milking,seven swans a-swimming,six geese a-laying, five golden rings, four calling birds,three French hens, two turtle doves,and a partridge in a pear tree. ");
			break;
			case 9:
			puts("my true love sent to me.");
			puts("Nine ladies dancing,eight maids a-milking,seven swans a-swimming,six geese a-laying, five golden rings, four calling birds,three French hens, two turtle doves,and a partridge in a pear tree. ");
			break;
			case 10:
			puts("my true love sent to me.");
			puts("Ten lords a-leaping, nine ladies dancing,eight maids a-milking,seven swans a-swimming,six geese a-laying, five golden rings, four calling birds,three French hens, two turtle doves,and a partridge in a pear tree. ");
			break;
    		case 11:
			puts("my true love sent to me.");
			puts("Eleven pipers piping, ten lords a-leaping, nine ladies dancing,eight maids a-milking,seven swans a-swimming,six geese a-laying, five golden rings, four calling birds,three French hens, two turtle doves,and a partridge in a pear tree. ");
			break;
			case 12:
			puts("my true love sent to me.");
			puts("Twelve drummers drumming, eleven pipers piping, ten lords a-leaping, nine ladies dancing,eight maids a-milking,seven swans a-swimming,six geese a-laying, five golden rings, four calling birds,three French hens, two turtle doves,and a partridge in a pear tree. ");
			break;
		}
	system("PAUSE");
	}
	return 0;
}
