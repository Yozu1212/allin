#include<stdio.h>
#include<string.h>

int main(void)
{ 
   	printf("%s\n",strerror(2));
	system("pause");
	return 0;
} 
