#include <stdio.h>
#include <stdlib.h>
void f(const int *xPtr);
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int y;
	f(&y);
	system("PAUSE");
	return 0;
}

void f(const int *xPtr);
{
	*xPtr = 100;
}
